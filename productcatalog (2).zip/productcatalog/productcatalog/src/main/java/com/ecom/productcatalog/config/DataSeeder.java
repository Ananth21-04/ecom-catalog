package com.ecom.productcatalog.config;

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.ecom.productcatalog.model.Category;
import com.ecom.productcatalog.model.Product;
import com.ecom.productcatalog.repo.CategoryRepository;
import com.ecom.productcatalog.repo.ProductRepository;

@Component
public class DataSeeder implements CommandLineRunner {
	public DataSeeder(ProductRepository productRepository, CategoryRepository categoryRepository) {
		super();
		this.productRepository = productRepository;
		this.categoryRepository = categoryRepository;
	}

	private final ProductRepository productRepository;
	private final CategoryRepository categoryRepository;

	@Override
	public void run(String... args) throws Exception {
		// clear all existing data
		productRepository.deleteAll();
		categoryRepository.deleteAll();

		// create Categories
		Category electronics = new Category();
		electronics.setName("Electronics");

		Category clothing = new Category();
		clothing.setName("Clothing");

		Category home = new Category();
		home.setName("Home and Kitchen");

		categoryRepository.saveAll(Arrays.asList(electronics, home, clothing));

		// create products
		Product phone = new Product();
		phone.setName("Smart Phone");
		phone.setDescription("Latest model smartphone with amazing features");
		phone.setImageUrl("https://placehold.co/600x400");
		phone.setPrice(16000.00);
		phone.setCategory(electronics);

		Product laptop = new Product();
		laptop.setName("Laptop");
		laptop.setDescription("High performance laptop for work and play");
		laptop.setImageUrl("https://placehold.co/600x400");
		laptop.setPrice(49000.00);
		laptop.setCategory(electronics);

		Product jacket = new Product();
		jacket.setName("Winter jacket");
		jacket.setDescription("Best Quality jacket");
		jacket.setImageUrl("https://placehold.co/600x400");
		jacket.setPrice(5000.00);
		jacket.setCategory(clothing);

		Product blender = new Product();
		blender.setName("Blender");
		blender.setDescription("Best Quality blender");
		blender.setImageUrl("https://placehold.co/600x400");
		blender.setPrice(5500.00);
		blender.setCategory(home);
		productRepository.saveAll(Arrays.asList(phone, laptop, jacket, blender));

	}

}
