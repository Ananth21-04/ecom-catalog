// CategoryFilter.jsx
function CategoryFilter({ categories, onSelect }) {
  return (
    <select className="form-control" onChange={(e) => onSelect(e.target.value)}>
      <option value="">All Categories</option>
      {categories.map(cat => (
        <option key={cat.id} value={cat.name}>{cat.name}</option>
      ))}
    </select>
  );
}

export default CategoryFilter;
